create view view_bill
            (bill_id, address_name, phone, province, district, commune, details, invoice_date, discount_code,
             discount_value) as
SELECT ba.bill_id,
       ba.address_name,
       ba.phone,
       ba.province,
       ba.district,
       ba.commune,
       ba.details,
       ba.invoice_date,
       d.discount_code,
       d.discount_value
FROM bill_address ba
         LEFT JOIN discount d ON ba.discount_id = d.discount_id;

alter table view_bill
    owner to hrthdlukbngedk;

