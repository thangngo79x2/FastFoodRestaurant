create view view_product
            (product_id, category_code, product_code, product_name, product_note, product_price, product_discount) as
SELECT p.product_id,
       c.category_code,
       p.product_code,
       p.product_name,
       p.product_note,
       p.product_price,
       p.product_discount
FROM product p
         JOIN categories c ON c.category_id = p.category_id;

alter table view_product
    owner to hrthdlukbngedk;

