create view bill_address
            (bill_id, address_name, phone, province, district, commune, details, invoice_date, discount_id) as
SELECT b.bill_id,
       a.address_name,
       a.phone,
       a.province,
       a.district,
       a.commune,
       a.details,
       b.invoice_date,
       b.discount_id
FROM bill b
         JOIN address a ON a.address_id = b.address_id
WHERE b.processed = 0;

alter table bill_address
    owner to hrthdlukbngedk;

