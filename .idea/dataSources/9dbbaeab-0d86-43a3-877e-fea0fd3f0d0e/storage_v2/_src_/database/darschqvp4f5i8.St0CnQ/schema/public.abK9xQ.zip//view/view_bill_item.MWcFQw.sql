create view view_bill_item (item_id, bill_id, product_price, product_discount, product_name, quantity) as
SELECT bi.item_id,
       bi.bill_id,
       p.product_price,
       p.product_discount,
       p.product_name,
       bi.quantity
FROM bill_item bi
         JOIN product p ON p.product_id = bi.product_id;

alter table view_bill_item
    owner to hrthdlukbngedk;

